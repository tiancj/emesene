#coding=utf-8
from PyQt4 import QtCore
import types,string,os,threading as th
"""
        elif e['value']['status'] ==u'online': #上线
            yy[e['value']['uin']]['status'] = e['value']['status']
        elif e['value']['status'] ==u'busy': #忙
            yy[e['value']['uin']]['status'] = e['value']['status']
        elif e['value']['status'] ==u'away': #总是
            yy[e['value']['uin']]['status'] = e['value']['status']
"""
class Status(object):
    @staticmethod
    def status(yy,zz,e,main):
        if e['value']['status'] ==u'offline': #离线
            yy[e['value']['uin']]['status'] = 'out'
        else:
            yy[e['value']['uin']]['status'] = 'online'
        try:
            main.ui.treeqq.emit(QtCore.SIGNAL("sortsignal(int)"),yy[e['value']['uin']]['categories'])
        except KeyboardInterrupt:
            pass
    @staticmethod
    def group_message(msgnum,main,xx,e):
        if msgnum%2 ==0:
            icon = 'ico/msg.jpg'
        else:
            icon = xx[e]['img']
        main.ui.treeqq.emit(QtCore.SIGNAL("qqgface"), e,icon)
    @staticmethod
    def message(msgnum,main,yy,zz,e):
        if msgnum%2 ==0:
            yy[e]['object'].parent().setText(0,'')
            icon = 'ico/msg.jpg'
        else:
            yy[e]['object'].parent().setText(0,u"{name}({online}/{count})".format(name=zz[yy[e]['categories']]['name'],count=zz[yy[e]['categories']]['count'],online=zz[yy[e]['categories']]['online']))
            icon = yy[e]['img']
        main.ui.treeqq.emit(QtCore.SIGNAL("qqface"), e,yy[e]['categories'],icon)
    @staticmethod
    def group_message_add(*args):
        cmsg,myclass,mydata,value,obj,nick,msg,timet = args
        t = []
        sstyle = []
        for i in msg:
            if type(i) == types.UnicodeType:
                t.append(cmsg.convertmsg(i))
            if type(i) == types.ListType:
                if i[0] == u'font':
                    sstyle.append(i[1]['name'])
                    sstyle.append(i[1]['size'])
                    sstyle.append(i[1]['color'])
                elif i[0] == u'face':
                    t.append(cmsg.replacefacemsg(i[1]))
                elif i[0] ==u'cface':
                    t.append(u'[自定义图片]')
                    #th.Thread(target=Status.getimg,args=(value['from_uin'],value['msg_id'],i[1],myclass,mydata)).start()
                    #t.append(cmsg.definefaceimg('ico/qq.jpg'))
        tomsg = string.join(t,'')
        html = cmsg.formathtml(nick,cmsg.formattime(timet),tomsg,style = (sstyle[2],sstyle[1],sstyle[0],'blue'))
        obj.ui.msg.emit(QtCore.SIGNAL('add'),html)
        del t,sstyle,tomsg,html
    @staticmethod
    def message_add(*args):
        cmsg,myclass,mydata,value,obj,nick,msg,timet = args
        t = []
        sstyle = []
        for i in msg:
            if type(i) == types.UnicodeType:
                t.append(cmsg.convertmsg(i))
            if type(i) == types.ListType:
                if i[0] == u'font':
                    sstyle.append(i[1]['name'])
                    sstyle.append(i[1]['size'])
                    sstyle.append(i[1]['color'])
                elif i[0] == u'face':
                    t.append(cmsg.replacefacemsg(i[1]))
                elif i[0] ==u'cface':
                    th.Thread(target=Status.getimg,args=(value['from_uin'],value['msg_id'],i[1],myclass,mydata)).start()
                    t.append(cmsg.definefaceimg('ico/qq.jpg'))
                    t.append(u'[自定义图片]')
        tomsg = string.join(t,'')
        html = cmsg.formathtml(nick,cmsg.formattime(timet),tomsg,style = (sstyle[2],sstyle[1],sstyle[0],'blue'))
        #这里出错
        obj.ui.msg.emit(QtCore.SIGNAL('add'),html)
        del t,sstyle,tomsg,html
    @staticmethod
    def getimg(*t):
        uin,mid,filename,myclass,mydata = t
        simg=None
        data = myclass.getG().get_cface2(uin,mid,filename)
        """
        typeimg = {'gif':'image/gif','bmp':'image/bmp','jpg':'image/jpeg'}
        for i in typeimg:
            if ('%s'% data[1]).find(self.typeimg[i]) != -1:
                img = i #获取头像图片类型
                break
        """
        #在这里为图标添加数据
        simg = './data/tw/{0}/temp/{1}'.format(mydata.get('qq'),filename)
        f = open(simg,'wb')
        f.write(data[0])
        f.close()
        del uin,mid,filename,myclass
        return simg
    @staticmethod
    def message_box(mydata,uin):
        mydata.get('message','messagebox').add(uin)
    @staticmethod
    def messagegroup_box(mydata,uin):
        mydata.get('messagegroup','messagebox').add(uin)
    @staticmethod
    def message_box_del(mydata,uin):
        try:
            mydata.get('message','messagebox').remove(uin)
        except KeyError:
            pass
    @staticmethod
    def messagegroup_box_del(mydata,uin):
        try:
            mydata.get('messagegroup','messagebox').remove(uin)
        except KeyError:
            pass



class Sound(object):
    def __init__(self):
        import platform
        if platform.system()=='Linux':
            self.os = 1
        else:
            import winsound
            self.os = 2
    def play(self,file):
        if self.os ==1:
            os.popen('aplay '+file)
        elif self.os ==2:
            winsound.PlaySound(file,winsound.SND_FILENAME)
    def msg(self):
        mp3="./data/sound/msg.wav"
        self.play(mp3)
        pass
    def system(self):
        mp3="./data/sound/system.wav"
        self.play(mp3)
    def global_(self):
        mp3="./data/sound/Global.wav"
        self.play(mp3)
