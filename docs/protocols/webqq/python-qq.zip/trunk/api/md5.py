#coding=utf-8
#qq密码加密类 webqq版
import hashlib
class QQmd5:
    def __init__(self):
        pass
    def md5(self,password=None,verifycode=None):
        #QQ密码加密部份
        return hashlib.md5( (self.__md5_3((password).encode('utf-8')) + (verifycode).upper()).encode('utf-8')).hexdigest().upper()
        pass
    def __md5_3(self,str):
        #QQ密码md5_3部份
        return hashlib.md5(hashlib.md5(hashlib.md5(str).digest()).digest()).hexdigest().upper()
        pass