#coding=utf-8
import re,time
from cgi import escape
s = "%Y-%m-%d %H:%M:%S"
faceid = [14,1,2,3,4,5,6,7,8,9,10,11,12,13,0,50,51,96,53,54,73,74,75,76,77,78,55,56,57,58,79,80,81,82,83,84,85,86,87,88,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,
	32,113,114,115,63,64,59,33,34,116,36,37,38,91,92,93,29,117,72,45,42,39,62,46,47,71,95,118,119,120,121,122,123,124,27,21,23,25,26,125,126,127,128,129,130,131,132,133,134,52,24,22,20,60,61,89,90,31,94,65,35,66,67,68,69,70,15,16,17,18,19,28,30,40,41,43,44,48,49]

facedict={14:0,1:1,2:2,3:3,4:4,5:5,6:6,7:7,8:8,9:9,10:10,11:11,12:12,13:13,0:14,50:15,51:16,96:17,53:18,54:19,73:20,74:21,75:22,76:23,77:24,78:25,55:26,56:27,57:28,58:29,79:30,80:31,81:32,82:33,83:34,84:35,85:36,86:37,87:38,88:39,97:40,
	98:41,99:42,100:43,101:44,102:45,103:46,104:47,105:48,106:49,107:50,108:51,109:52,110:53,111:54,112:55,32:56,113:57,114:58,115:59,63:60,64:61,59:62,33:63,34:64,116:65,36:66,37:67,38:68,91:69,92:70,93:71,29:72,117:73,72:74,45:75,42:76,39:77,62:78,46:79,47:80,71:81,95:82,118:83,119:84,120:85,121:86,122:87,123:88,124:89,27:90,21:91,23:92,25:93,26:94,125:95,126:96,127:97,128:98,129:99,130:100,131:101,132:102,133:103,134:104,52:105,24:106,22:107,20:108,60:109,61:110,89:111,90:112,31:113,94:114,65:115,
	35:116,66:117,67:118,68:119,69:120,70:121,15:122,16:123,17:124,18:125,19:126,28:127,30:128,40:129,41:130,43:131,44:132,48:133,49:134}
RE_LINK = re.compile(
r"""(?i)\b((?:[a-z][\w-]+:(?:/{1,3}|[a-z0-9%])|www\d{0,3}[.]|[a-z0-9.\-]+[.][a-z]{2,4}/)(?:[^\s()<>]+|\(([^\s()<>]+|(\([^\s()<>]+\)))*\))+(?:\(([^\s()<>]+|(\([^\s()<>]+\)))*\)|[^\x80-\xff\s`!()\[\]{};:'".,<>?«»“”‘’]))"""

)
RE_SPACE = re.compile(""" ( +)""")

def replace_space(match):
    return " "+len(match.groups()[0])*"&nbsp;"

def replace_link(match):
    #p, g = match.groups()
    #if p in ('"', ">") or p.isalnum():
    #    return "%s%s"%(p, g)
    #else:
    g = match.groups()[0]
    if "." not in g:
        return g
    #g = escape(g)
    link = g
    if not link.startswith("http"):
        link = "http://%s"%link
    return """<a target="_blank" href="%s" rel="nofollow">%s</a>""" %(link, g)

def txt_withlink(s):
    rs = []
    #s = escape(s)
    s = RE_LINK.sub(replace_link, s)
    return s
#print txt_withlink('<html>\nhttp://www.qq.com/?<>aa.html\ndad')
def txt2htm_withlink(s):
    rs = []
    #s = escape(s)
    s = s.replace("\n", "\n<br>")
    s = RE_LINK.sub(replace_link, s)
    s = RE_SPACE.sub(replace_space, s)
    return s
def convertmsg(msg): #显示在当前窗口
    return txt_withlink(u'{0}'.format(msg).replace(r'<','&lt;').replace(r'>','&gt;').replace(b'\r','<br>').replace(b'\n','<br>'))
def sendmsg(msg): #发送出去的
    return u'{0}'.format(msg).replace(b'\n',b'\\n')
def formattime(timedate,s="%Y-%m-%d %H:%M:%S"):
    return time.strftime(s,time.gmtime(int(timedate) + 8*60*60))
def formathtml(nick,timedate,msg,style=('000000','12',u'宋体','black')):
    return u'<font style="color:{sty[3]};">{0} {1}</font> <br><font style="font-family:{sty[2]};color:#{sty[0]};font-size:{sty[1]}pt;">{2}</font>'.format(nick,timedate,msg,sty = style)
def replacefacemsg(face):
    faceimg = facekey(face)
    return u'<img src="./ico/face/{0}.gif" />'.format(faceimg)
def facekey(x):
	try:
		return facedict.get(int(x))
	except Exception:
		return 0
def definefaceimg(img):
    return u'<img src="{0}" />'.format(img)
#没有用
def sendreplacefacemsg(msg,face):
    return u'{0}'.format(msg).replace('<img src="./ico/face/%s.gif">'%face,["face",face]) #print replacefacemsg(126)
