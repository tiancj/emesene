#coding=utf-8
from Api_socket import Api_connect
class QQ_CLASS:
    __g = 0
    def __init__(self,mydata):
        #self.qq = Api_connect()
        #qq.Login(644826377,'19890107er')
        #qq.request_login()
        self.mydata = mydata
        self.g()
        pass
    def g(self):
        self.__g = Api_connect(self.mydata)
        pass
    def Login(self,QQ,PASSWORD):
        if len(QQ) != 0 and len(PASSWORD) != 0:
            self.__g.Login(QQ,PASSWORD)
            getverifycode = self.__g.getverifycode()
            if getverifycode[0] ==1:
                return 3 #需要验证码
            return self.verityLogin()
        else:
            return -1
        pass
    def verityLogin(self):
        login = self.__g.request_login()
        if login.find(u'登录成功') != -1:
            info = self.__g.request_login2()
            if info['retcode'] == 0: #登陆成功
                return info
            else: #失败的错误代码
                return info['retcode']
        elif login.find(u'不正确') != -1:
            # '你输入的帐号或者密码不正确，请重新输入。'
            return 1
        else:
            # '登录失败'
            return 2
        pass
    def get_info(self):
        return self.getG().get_friend_info2()
        pass
    def get_user_friends(self):
        return self.getG().get_user_friends2()
        pass
    def get_group_name_list(self):
        return self.getG().get_group_name_list_mask2()
        pass
    def get_online(self):
        return self.getG().get_online_buddies2()
        pass
    def poll(self):
        return self.getG().poll2_()
        pass
    def get_tip(self):
        self.getG().get_msg_tip_()
    def getG(self):
        return self.__g
        pass
    def setverifycode(self,value):
        self.getG().setverifycode(value)
        pass
#qq = QQ_CLASS()
#qq.g('webqq')
#if qq.Login(644826377,'19890107er') is None:
#    qq.getG().get_friend_info2()
#    qq.getG().get_user_friends2()
#    qq.getG().get_group_name_list_mask2()
#    qq.getG().poll2_()
#    qq.getG().get_msg_tip_()
