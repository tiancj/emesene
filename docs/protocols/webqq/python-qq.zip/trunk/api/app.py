#coding=utf-8
def removemsg(a,i,mydata):
    try:
        a.remove(i)
    except ValueError as t:
        print >> mydata.get('log','debug'),t
        return False