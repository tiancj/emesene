# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\dingyangfan\Desktop\QQ\QQ.ui'
#
# Created: Wed Oct 26 11:39:28 2011
#      by: PyQt4 UI code generator 4.8.5
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_QQForm(object):
    def setupUi(self, QQForm):
        QQForm.setObjectName("QQForm")
        QQForm.resize(314, 177)
        QQForm.setWindowTitle(u"登录窗口")
        self.login = QtGui.QPushButton(QQForm)
        self.login.setGeometry(QtCore.QRect(100, 120, 75, 23))
        self.login.setText(u"登录")
        self.login.setObjectName("login")
        self.close = QtGui.QPushButton(QQForm)
        self.close.setGeometry(QtCore.QRect(180, 120, 75, 23))
        self.close.setText(u"关闭")
        self.close.setObjectName("close")
        self.qq = QtGui.QLineEdit(QQForm)
        self.qq.setGeometry(QtCore.QRect(90, 30, 181, 21))
        self.qq.setObjectName("qq")
        self.pswd = QtGui.QLineEdit(QQForm)
        self.pswd.setGeometry(QtCore.QRect(90, 70, 181, 21))
        self.pswd.setObjectName("pswd")
        self.label = QtGui.QLabel(QQForm)
        self.label.setGeometry(QtCore.QRect(40, 30, 54, 20))
        self.label.setText(u"QQ号：")
        self.label.setScaledContents(False)
        self.label.setObjectName("label")
        self.label_2 = QtGui.QLabel(QQForm)
        self.label_2.setGeometry(QtCore.QRect(40, 70, 54, 20))
        self.label_2.setText(u"密码：")
        self.label_2.setScaledContents(False)
        self.label_2.setObjectName("label_2")
        self.status = QtGui.QComboBox(QQForm)
        self.status.setGeometry(QtCore.QRect(41, 121, 50, 20))
        self.status.setObjectName("status")
        self.status.addItem("")
        self.status.setItemText(0,u"在线")
        self.status.addItem("")
        self.status.setItemText(1,u"隐身")
        self.status.addItem("")
        self.status.setItemText(2,u"离开")
        self.status.addItem("")
        self.status.setItemText(3,u"离线")

        self.retranslateUi(QQForm)
        QtCore.QObject.connect(self.close, QtCore.SIGNAL("clicked()"), QQForm.close)
        QtCore.QMetaObject.connectSlotsByName(QQForm)

    def retranslateUi(self, QQForm):
        pass

class Ui_QQ_veritycode(object):
    def setupUi(self, QQ_veritycode):
        QQ_veritycode.setObjectName("QQ_veritycode")
        QQ_veritycode.resize(218, 90)
        QQ_veritycode.setWindowTitle(u"验证码")
        self.label = QtGui.QLabel(QQ_veritycode)
        self.label.setGeometry(QtCore.QRect(10, 0, 101, 61))
        self.label.setStyleSheet("font: 75 italic 20pt \"Agency FB\";")
        self.label.setText(u"验证码：")
        self.label.setObjectName("label")
        self.veritycode = QtGui.QLineEdit(QQ_veritycode)
        self.veritycode.setGeometry(QtCore.QRect(110, 10, 101, 41))
        self.veritycode.setStyleSheet("font: 22pt \"Agency FB\";")
        self.veritycode.setObjectName("veritycode")
        self.codeenter = QtGui.QPushButton(QQ_veritycode)
        self.codeenter.setGeometry(QtCore.QRect(130, 60, 75, 23))
        self.codeenter.setText(u"确定")
        self.codeenter.setObjectName("codeenter")

        self.retranslateUi(QQ_veritycode)
        QtCore.QMetaObject.connectSlotsByName(QQ_veritycode)

    def retranslateUi(self, QQ_veritycode):
        pass

class Ui_qqMain(object):
    def setupData(self,data):
        self.__data = data
    def qqface(self,uin,guin,b):
        icon = QtGui.QIcon()
        pixmap = QtGui.QPixmap(b)
        icon.addPixmap(pixmap)
        if icon.isNull() is False:
            self.__data.get('sortlist')[guin][uin]['object'].setIcon(0,icon)
        else:
            icon.addPixmap(QtGui.QPixmap('ico/qq.jpg'))
            self.__data.get('sortlist')[guin][uin]['object'].setIcon(0,icon)
        del icon,pixmap
    def qqgface(self,guin,b):
        icon = QtGui.QIcon()
        pixmap = QtGui.QPixmap(b)
        icon.addPixmap(pixmap)
        if icon.isNull() is False:
            self.__data.get('groupsortlist')[guin]['object'].setIcon(0,icon)
        else:
            icon.addPixmap(QtGui.QPixmap('ico/gqq.jpg'))
            self.__data.get('groupsortlist')[guin]['object'].setIcon(0,icon)
        del icon,pixmap
    def sortsignal(self,t):
        sortlist = self.__data.get('sortlist')
        sorttype = self.__data.get('sorttype')
        groupid = int(t)
        k = 0
        o = 0
        for r,v in sorted(sortlist[groupid].items(),key=lambda x:x[1]['status'], reverse=False):
            t = self.treeqq.topLevelItem(groupid).child(k)
            if v.has_key('markname'):
                t.setText(0, v['markname'])
            else:
                t.setText(0, v['nick'])
            t.setIcon(0,QtGui.QIcon(v['img']))
            if v['status'] == 'out':
                t.setDisabled(True) #离线的图标变暗
            else:
                o +=1
                t.setDisabled(False) #在线的+1
            t.info = v
            v['object'] = t
            v['i'] = k
            k += 1
        self.treeqq.topLevelItem(groupid).setText(0,\
        u"{name}({online}/{count})".format(name=sorttype[groupid]['name'],\
        count=k,\
        online=o))
        del k,o,groupid,sortlist,sorttype
    def triggleface(self,i,j,simg):
        t = i,j
        icon = QtGui.QIcon()
        pixmap = QtGui.QPixmap(simg)
        icon.addPixmap(pixmap)
        if icon.isNull() is False:
            self.treeqq.topLevelItem(t[0]).child(t[1]).setIcon(0,icon)
            self.treeqq.topLevelItem(t[0]).child(t[1]).info['img'] = simg
        del t,icon,pixmap
    def trigglegface(self,i,simg):
        icon = QtGui.QIcon()
        pixmap = QtGui.QPixmap(simg)
        icon.addPixmap(pixmap)
        if icon.isNull() is False:
            self.groupqq.topLevelItem(i).setIcon(0,icon)
            self.groupqq.topLevelItem(i).info['img'] = simg
        del icon,pixmap
    def sortList(self):
        t = {} #好友
        c = {} #分组
        a = self.__data.get('friends')
        for i in a['result']['categories']:
            c[i['index']] = {}
            c[i['index']] = i
            t[i['index']] = {}
            for j in a['result']['friends']:
                if i['index'] == j['categories']:
                    t[i['index']][j['uin']] = j
                    t[i['index']][j['uin']]['status'] = 'out'
                    for o in self.__data.get('online')['result']:
                        if o['uin'] == j['uin']:
                            if o['status'] != u'offline':
                                t[i['index']][j['uin']]['status'] = 'online' #在线和离线的状态
            for k in a['result']['info']:
                if t[i['index']].has_key(k['uin']):
                    for l in k:
                        if l != 'uin':
                            t[i['index']][k['uin']][l]=k[l]
            for q in a['result']['marknames']:
                if t[i['index']].has_key(q['uin']):
                    t[i['index']][q['uin']]['markname'] = q['markname']
            for w in a['result']['vipinfo']:
                if t[i['index']].has_key(w['u']):
                    t[i['index']][w['u']]['is_vip'] = w['is_vip']
                    t[i['index']][w['u']]['vip_level'] = w['vip_level']
        self.sortlist = t #好友列表
        self.sorttype = c #分组
        del t,c,a
        pass
    def Groupsortlist(self):
        t = {}
        a = self.__data.get('group')['result']['gnamelist']
        for i in a:
            t[i['code']] = {}
            t[i['code']] = i
        self.groupsortlist = t
        del t
        pass
    def setupUi(self, qqMain):
        qqMain.setObjectName("qqMain")
        qqMain.resize(213, 481)
        qqMain.setWindowTitle(u"QQ面板")
        self.qqwidget = QtGui.QWidget(qqMain)
        self.qqwidget.setObjectName("qqwidget")
        self.qqtab = QtGui.QTabWidget(self.qqwidget)
        self.qqtab.setGeometry(QtCore.QRect(0, 40, 211, 441))
        self.qqtab.setObjectName("qqtab")
        self.qq = QtGui.QWidget()
        self.qq.setObjectName("qq")
        self.treeqq = QtGui.QTreeWidget(self.qq)
        self.treeqq.setGeometry(QtCore.QRect(-1, -1, 210, 420))
        self.treeqq.setObjectName("treeqq") #qq好友

        self.treeqq.headerItem().setText(0,u"QQ好友")
        self.treeqq.headerItem().setIcon(0,QtGui.QIcon('ico/1.gif')) #QQ导航图标
        self.treeqq.setIconSize(QtCore.QSize(20,20)) #图标大小
        #self.treeqq.headerItem().setSizeHint(0,QtCore.QSize(30,60)) #让导航变高变宽
        #self.sortlist
        j = 0
        for i in self.sorttype:
            item_0 = QtGui.QTreeWidgetItem(self.treeqq)
            k = 0
            self.sorttype[i]['count'] = len(self.sortlist[self.sorttype[i]['index']])
            self.sorttype[i]['online'] = 0
            for r,v in sorted(self.sortlist[self.sorttype[i]['index']].items(),key=lambda x:x[1]['status'], reverse=False):
                item_1 = QtGui.QTreeWidgetItem(item_0)
                if self.sortlist[self.sorttype[i]['index']][r]['status'] == 'out':
                    item_1.setDisabled(True) #离线的图标变暗
                else:
                    self.sorttype[i]['online'] +=1 #在线的+1
                if self.sortlist[self.sorttype[i]['index']][r].has_key('markname'):
                    item_1.setText(0, self.sortlist[self.sorttype[i]['index']][r]['markname'])
                else:
                    item_1.setText(0, self.sortlist[self.sorttype[i]['index']][r]['nick'])
                item_1.setIcon(0,QtGui.QIcon('ico/qq.jpg')) #图标
                item_1.setSizeHint(0,QtCore.QSize(90,22))  #行大小
                self.sortlist[self.sorttype[i]['index']][r]['g'] =j
                self.sortlist[self.sorttype[i]['index']][r]['i'] =k
                item_1.info= self.sortlist[self.sorttype[i]['index']][r]
                item_1.info['img'] = 'ico/qq.jpg'
                self.sortlist[self.sorttype[i]['index']][r]['object'] = item_1
                k = k + 1
            item_0.setText(0,u"{name}({online}/{count})".format(name=self.sorttype[i]['name'],count=self.sorttype[i]['count'],online=self.sorttype[i]['online']))
            o = 0
            j = j + 1
        self.__data.set('sortlist',self.sortlist) #保存新的带有图标的好友列表
        self.__data.set('sorttype',self.sorttype)
        del self.sortlist,self.sorttype
        self.qqtab.addTab(self.qq,"")

        self.group = QtGui.QWidget()
        self.group.setObjectName("group")
        self.groupqq = QtGui.QTreeWidget(self.group)
        self.groupqq.setGeometry(QtCore.QRect(-1, -1, 210, 420))
        self.groupqq.setObjectName("groupqq") #qq群
        self.groupqq.headerItem().setText(0,u"QQ群")
        self.groupqq.headerItem().setIcon(0,QtGui.QIcon('ico/1.gif')) #QQ导航图标
        u = 0
        for t in self.groupsortlist:
            item_0 = QtGui.QTreeWidgetItem(self.groupqq)
            item_0.setText(0,self.groupsortlist[t]['name'])
            item_0.setIcon(0,QtGui.QIcon(QtGui.QPixmap('ico/qq.jpg'))) #图标
            self.groupsortlist[t]['i'] = u
            item_0.info = self.groupsortlist[t]
            item_0.info['img'] = 'ico/gqq.jpg'
            self.groupsortlist[t]['object'] = item_0
            u = u +1
        self.__data.set('groupsortlist',self.groupsortlist) #保存新的带有图标的好友列表
        del self.groupsortlist
        self.qqtab.addTab(self.group,"")

        #print self.__data.get('group')['result']['gnamelist']
        self.qqstatus = QtGui.QComboBox(self.qqwidget)
        self.qqstatus.setGeometry(QtCore.QRect(150, 20, 50, 20))
        self.qqstatus.setObjectName("qqstatus")
        self.qqstatus.addItem("")
        self.qqstatus.setItemText(0,u"在线")
        self.qqstatus.addItem("")
        self.qqstatus.setItemText(1,u"隐身")
        self.qqstatus.addItem("")
        self.qqstatus.setItemText(2,u"离开")
        self.qqstatus.addItem("")
        self.qqstatus.setItemText(3,u"离线")


        qqMain.setCentralWidget(self.qqwidget)
        self.retranslateUi(qqMain)
        self.qqtab.setCurrentIndex(0)
        QtCore.QMetaObject.connectSlotsByName(qqMain)

    def retranslateUi(self, qqMain):
        __sortingEnabled = self.treeqq.isSortingEnabled()
        self.treeqq.setSortingEnabled(False)
        self.treeqq.setSortingEnabled(__sortingEnabled)
        self.qqtab.setTabText(self.qqtab.indexOf(self.qq),u"QQ好友")
        __sortingEnabled = self.groupqq.isSortingEnabled()
        self.groupqq.setSortingEnabled(False)
        self.groupqq.setSortingEnabled(__sortingEnabled)
        self.qqtab.setTabText(self.qqtab.indexOf(self.group),u"QQ群")

class Ui_qqMsg(object):
    def setupUi(self, qqMsg):
        qqMsg.setObjectName("qqMsg")
        qqMsg.resize(545, 410)
        qqMsg.setWindowTitle("")
        self.ok = QtGui.QPushButton(qqMsg)
        self.ok.setGeometry(QtCore.QRect(450, 380, 75, 23))
        self.ok.setText(u"发送")
        self.ok.setObjectName("ok")
        self.close = QtGui.QPushButton(qqMsg)
        self.close.setGeometry(QtCore.QRect(360, 380, 75, 23))
        self.close.setText(u"关闭")
        self.close.setObjectName("close")
        self.comment = QtGui.QTextEdit(qqMsg)
        self.comment.setGeometry(QtCore.QRect(20, 300, 501, 71))
        self.comment.setHtml("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n" \
                            "<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"\
                            "p, li { white-space: pre-wrap; }\n"\
                            "</style></head><body style=\" font-family:\'SimSun\'; font-size:9pt; font-weight:400; font-style:normal;\">\n"\
        "</body></html>")
        self.comment.setObjectName("comment")
        self.msg = QtGui.QTextBrowser(qqMsg)
        self.msg.setReadOnly(True)
        self.msg.scroll(self.msg.x(),self.msg.y())
        self.msg.setGeometry(QtCore.QRect(20, 70, 501, 201))
        self.msg.setHtml("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n" \
                        "<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"\
                        "p, li { white-space: pre-wrap; }\n"\
                        "</style></head><body style=\" font-family:\'SimSun\'; font-size:9pt; font-weight:400; font-style:normal;\">\n"\
        "</body></html>")
        self.msg.setObjectName("msg")

        self.toolbar = QtGui.QToolButton(qqMsg)
        self.toolbar.setText(u'表情')
        self.toolbar.setGeometry(QtCore.QRect(20,272,35,25))
        self.toolbar.setObjectName('toolbar')
        self.childw = self.childW()
        #self.childw.show()


        self.qq = QtGui.QLabel(qqMsg)
        self.qq.setGeometry(QtCore.QRect(77, 5, 371, 16))
        self.qq.setStyleSheet(u"color: rgb(0, 0, 0);\nfont: 75 9pt \"宋体\";")
        self.qq.setText(u"QQ:8094731(丁泓懿)")
        self.qq.setObjectName("qq")
        self.img = QtGui.QLabel(qqMsg)
        self.img.setGeometry(QtCore.QRect(10, 10, 61, 51))
        self.img.setText("TextLabel")
        self.img.setObjectName("img")
        self.info = QtGui.QLabel(qqMsg)
        self.info.setGeometry(QtCore.QRect(76, 25, 440, 12))
        self.info.setText(u"签名")
        self.info.setObjectName("info")

        self.retranslateUi(qqMsg)
        QtCore.QMetaObject.connectSlotsByName(qqMsg)

    def retranslateUi(self, qqMsg):
        pass
    def childW(self):
        childWvar = QtGui.QWidget()
        childWvar.resize(200,200)
        return childWvar

class Ui_qqGroupMsg(object):
    def setupUi(self, qqGroupMsg):
        qqGroupMsg.setObjectName("qqGroupMsg")
        qqGroupMsg.resize(545, 410)
        qqGroupMsg.setWindowTitle("")
        self.ok = QtGui.QPushButton(qqGroupMsg)
        self.ok.setGeometry(QtCore.QRect(270, 384, 75, 23))
        self.ok.setText(u"发送")
        self.ok.setObjectName("ok")
        self.close = QtGui.QPushButton(qqGroupMsg)
        self.close.setGeometry(QtCore.QRect(190, 384, 75, 23))
        self.close.setText(u"关闭")
        self.close.setObjectName("close")
        self.comment = QtGui.QTextEdit(qqGroupMsg)
        self.comment.setGeometry(QtCore.QRect(20, 300, 331, 80))
        self.comment.setHtml("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'SimSun\'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"></p></body></html>")
        self.comment.setObjectName("comment")
        self.msg = QtGui.QTextBrowser(qqGroupMsg)
        self.msg.setGeometry(QtCore.QRect(20, 50, 331, 240))
        self.msg.setHtml("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'SimSun\'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"></p></body></html>")
        self.msg.setObjectName("msg")
        self.qqgroup = QtGui.QLabel(qqGroupMsg)
        self.qqgroup.setGeometry(QtCore.QRect(60, 5, 271, 16))
        self.qqgroup.setStyleSheet(u"color: rgb(0, 0, 0);\nfont: 75 9pt \"宋体\";")
        self.qqgroup.setText(u"群名称")
        self.qqgroup.setObjectName("qqgroup")
        self.img = QtGui.QLabel(qqGroupMsg)
        self.img.setGeometry(QtCore.QRect(10, 10, 31, 31))
        self.img.setText(u"群头象")
        self.img.setObjectName("img")
        self.info = QtGui.QLabel(qqGroupMsg)
        self.info.setGeometry(QtCore.QRect(60, 25, 440, 12))
        self.info.setText(u"群说明")
        self.info.setObjectName("info")
        self.note = QtGui.QTextEdit(qqGroupMsg)
        self.note.setGeometry(QtCore.QRect(370, 50, 161, 121))
        self.note.setHtml("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'SimSun\'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"></p></body></html>")
        self.note.setObjectName("note")
        self.grouplist = QtGui.QListWidget(qqGroupMsg)
        self.grouplist.setGeometry(QtCore.QRect(370, 200, 161, 200))
        self.grouplist.setObjectName("grouplist")
        self.pushButton = QtGui.QPushButton(qqGroupMsg)
        self.pushButton.setGeometry(QtCore.QRect(369, 180, 163, 23))
        self.pushButton.setText(u"群友(90/10)")
        self.pushButton.setObjectName("pushButton")

        self.retranslateUi(qqGroupMsg)
        QtCore.QMetaObject.connectSlotsByName(qqGroupMsg)

    def retranslateUi(self, qqGroupMsg):
        __sortingEnabled = self.grouplist.isSortingEnabled()
        self.grouplist.setSortingEnabled(False)
        item = self.grouplist.item(0)
        item = self.grouplist.item(1)
        self.grouplist.setSortingEnabled(__sortingEnabled)
