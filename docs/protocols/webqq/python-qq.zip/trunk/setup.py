import os

os.popen('aplay ./data/sound/system.wav')